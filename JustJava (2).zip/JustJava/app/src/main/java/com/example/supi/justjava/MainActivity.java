package com.example.supi.justjava;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {
    int quantity = 99;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


   /**this is a plus button is clicked**/

    public void increment(View view) {
         if (quantity == 100){
             //show an error message toast
             Toast.makeText(this,"you cannot have more than 100 coffees",Toast.LENGTH_LONG).show();
             //Exit this method early because there is nothing left to do
             return;
         }
            quantity = quantity+1;
        displayQuantity(quantity);
    }

    /** this is a minus button is clicked**/

    public void decrement(View view) {
           if (quantity == 1){
               //toast message show an error
               Toast.makeText(this,"you cannot have less than one cup of coffee",Toast.LENGTH_LONG).show();
               //Exit this method because there is nothing to do
               return;
           }
            quantity = quantity-1;
        displayQuantity(quantity);
    }


    /**this method is called when the  order button is clicked**/
  public void submitOrder(View view) {

        //edit text name
       EditText nameField = (EditText)findViewById(R.id.name_field);
        String name = nameField.getText().toString();
        Log.v("Mainactivity","Name"+name);

     //figure out if the user need whipped cream
        CheckBox WhippedCreamCheckbox = (CheckBox) findViewById(R.id.whipped_cream_checkbox);
        boolean hasWhippedCream = WhippedCreamCheckbox.isChecked();

        //check with Logcat if the code is working proper
        Log.d("Mainactivity" ,"Has whipped cream:" +hasWhippedCream);

        //figure out if the user need chocolate
       CheckBox ChocolateCheckBox = (CheckBox) findViewById(R.id.chocolate_checkbox);
       boolean hasChocolate = ChocolateCheckBox.isChecked();

       //check with the Logcat if the code working proper
        Log.v("Mainactivity","Has Chocolate:" +hasChocolate);

       //calling the variables
        int price=calculatePrice(hasWhippedCream,hasChocolate);
      String priceMessage= createOrderSummary(name,price,hasWhippedCream,hasChocolate);
      Intent intent = new Intent(Intent.ACTION_SENDTO);
      intent.setData(Uri.parse("mailto:")); // only email apps should handle this
      intent.putExtra(Intent.EXTRA_SUBJECT, "just java order for " +name);
      intent.putExtra(Intent.EXTRA_TEXT, priceMessage);
      if (intent.resolveActivity(getPackageManager()) != null) {
          startActivity(intent);
      }
      displayMessage(priceMessage);
  }
//    {
//        Intent intent = new Intent(Intent.ACTION_VIEW);
//        intent.setData(Uri.parse("geo:47.6,-122.3"));
//        if (intent.resolveActivity(getPackageManager()) != null) {
//            startActivity(intent);
//        }
//    }
   /**
     * Calculates the price of the order.
     *
     * @return the total price
     */
    private int calculatePrice(boolean addWhippedCream , boolean addChocolate) {
        //price of one cup of coffee
        int baseprice = 5;

        //add £1 if the user wants whippedcream
        if(addWhippedCream){
            baseprice = baseprice + 1;

        }

        //add £2 if the user wants chocolate
        if(addChocolate){
            baseprice = baseprice + 2;
        }

        //add the total price by multipyling the baseprice and quantity
        int price = quantity*baseprice;
        return price;
    }

    /** create summary order **/
    //@param name of the customer
    //@param price of the order
    //@param addWhipped cream is wheather user wants or not the whipped cream toppings
    //@param addChocolate wheather the user wants or not the chocolate toppings
    //@return text summary


     private String createOrderSummary(String name,int price,boolean addWhippedCream,boolean addChocolate){
         String priceMessage = "Name:"+name;
         priceMessage = priceMessage + "\nAdd Whipped Cream?" + addWhippedCream;
         priceMessage = priceMessage + "\nAdd Chocolate?" + addChocolate;
         priceMessage = priceMessage +"\nQuantity:" +quantity;
         priceMessage = priceMessage + "\nTotal: " +"£"+ price;
         priceMessage = priceMessage+ "\nThank you!";
         return priceMessage;

     }/**
     * This method displays the given text on the screen.
     */
    private void displayMessage(String message) {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);
    }
    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayQuantity(int number ) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number );
    }
}
